package com.example.python_cde_compiler;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
